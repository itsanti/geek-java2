package hw1;

/**
 * all commands implements this
 *
 * @author Aleksandr Kurov
 * @version dated Авг. 16, 2018
 */

public interface ICommand {

    public void run();

}
