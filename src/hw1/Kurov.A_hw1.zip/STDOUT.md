```
SimpleBot is running now
running command SAY
hi
running command ISINT
yes

Process finished with exit code 0
```